#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""ok-ww「跳过剧情」修复包 v15 —— 安装后自检脚本（纯标准库）。

用法：
    python verify.py                  # 自动找 ok-ww 目录
    python verify.py --dir D:\\ok-ww  # 手动指定

检查项：
  ① SkipBaseTask.py / BaseWWTask.py 的 md5
  ② 7 张模板图片存在、非空、md5 匹配
  ③ coco 里 9 个新类别齐全，且每条标注都指向真实存在的图片
  ④ SkipBaseTask 能否被导入（用 ok-ww 自带 python；若环境不完整则退化为
     语法编译检查 + 常量/顺序检查，并在结尾明确说明退化了）
"""
import argparse
import hashlib
import json
import os
import py_compile
import subprocess
import sys
import tempfile

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import install as Pkg      # 复用包内的定位逻辑与期望 md5（install.py 的 main 有 __main__ 守卫）

passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  [通过] %s %s' % (name, extra))
    else:
        failed += 1
        print('  [失败] %s %s' % (name, extra))


def md5_of(path):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description='ok-ww 跳过剧情修复包 v%d 自检' % Pkg.VERSION)
    ap.add_argument('--dir', help='ok-ww 根目录')
    ap.add_argument('--no-pause', action='store_true')
    args = ap.parse_args()

    print('=' * 66)
    print('ok-ww「跳过剧情」修复包 v%d —— 安装后自检' % Pkg.VERSION)
    print('=' * 66)

    args.dir = args.dir
    working = Pkg.locate(argparse.Namespace(dir=args.dir))
    app_root = os.path.dirname(working)
    print('  ok-ww 应用目录：%s' % app_root)
    print('')

    print('[1] 代码文件 md5')
    skip_path = os.path.join(working, Pkg.REL_SKIP)
    p = skip_path
    if not os.path.exists(p):
        check('SkipBaseTask.py 存在', False)
        print('\n没找到目标文件，安装可能没成功。')
        sys.exit(1)
    got = md5_of(p)
    want, want_size = Pkg.EXPECTED['SkipBaseTask.py']
    check('SkipBaseTask.py md5 == %s' % want, got == want,
          '(实际 %s, %d 字节)' % (got, os.path.getsize(p)))
    check('SkipBaseTask.py 字节数 == %d' % want_size, os.path.getsize(p) == want_size)
    if got == Pkg.ORIG_SKIP_MD5:
        check('不是原版未打补丁状态', False, '(检测到原版 md5，说明补丁没装上)')

    pb = os.path.join(working, Pkg.REL_BASE)
    if os.path.exists(pb):
        gb = md5_of(pb)
        check('BaseWWTask.py 未被改动', gb == Pkg.BASEWW_EXPECTED_MD5,
              '(md5 %s%s)' % (gb, '' if gb == Pkg.BASEWW_EXPECTED_MD5
                              else '，与 v3.7.4 基准不同——若你不是 v3.7.4 属正常'))
    else:
        print('  [提示] 没找到 BaseWWTask.py，跳过该项')

    print('')
    print('[2] 7 张模板图片')
    img_dir = os.path.join(working, Pkg.REL_IMAGES, 'images')
    for rel in sorted(k for k in Pkg.EXPECTED if k.startswith('images/')):
        p = os.path.join(img_dir, os.path.basename(rel))
        want_md5, want_size = Pkg.EXPECTED[rel]
        if not os.path.exists(p):
            check('%s 存在' % rel, False)
            continue
        size = os.path.getsize(p)
        check('%-28s 存在且非空(%d B)' % (os.path.basename(rel), size), size > 0)
        check('%-28s md5 匹配' % os.path.basename(rel), md5_of(p) == want_md5)

    print('')
    print('[3] coco_annotations.json 结构')
    coco_path = os.path.join(working, Pkg.REL_COCO)
    if not os.path.exists(coco_path):
        check('coco 存在', False)
        sys.exit(1)
    data = json.load(open(coco_path, encoding='utf-8'))
    patch = json.load(open(os.path.join(Pkg.PKG_DIR, 'coco_patch.json'), encoding='utf-8'))
    want_names = {c['name'] for c in patch['categories']}
    names = {c['name'] for c in data['categories']}
    missing = sorted(want_names - names)
    check('9 个新类别齐全', not missing, '(缺少 %s)' % missing if missing else '')
    ids = [c['id'] for c in data['categories']]
    check('category id 无重复', len(ids) == len(set(ids)),
          '(%d 条, %d 个不同 id)' % (len(ids), len(set(ids))))
    aids = [a['id'] for a in data['annotations']]
    check('annotation id 无重复', len(aids) == len(set(aids)),
          '(%d 条, %d 个不同 id)' % (len(aids), len(set(aids))))
    iids = [i['id'] for i in data['images']]
    check('image id 无重复', len(iids) == len(set(iids)),
          '(%d 条, %d 个不同 id)' % (len(iids), len(set(iids))))
    cat_id = {c['id']: c['name'] for c in data['categories']}
    img_file = {i['id']: i['file_name'] for i in data['images']}
    for a in data['annotations']:
        nm = cat_id.get(a['category_id'])
        if nm in want_names:
            fn = img_file.get(a['image_id'])
            fp = os.path.join(working, Pkg.REL_IMAGES, str(fn).replace('/', os.sep))
            check('%-18s 标注指向的图片存在' % nm, os.path.exists(fp), '(%s)' % fn)
            bbox = a.get('bbox') or []
            check('%-18s bbox 合法(x,y,w,h 且 w,h>0)' % nm,
                  len(bbox) == 4 and bbox[2] > 0 and bbox[3] > 0, '(%s)' % bbox)
    print('  coco 计数：images=%d categories=%d annotations=%d'
          % (len(data['images']), len(data['categories']), len(data['annotations'])))

    print('')
    print('[4] 版本特征与导入检查')
    text = open(skip_path, encoding='utf-8').read()
    for marker in ('CG_HEXRING_THRESHOLD', 'CG_ANY_GLYPH_THRESHOLD', 'cg_skip_fixed',
                   'in_cinematic', 'MAX_SKIP_CLICKS'):
        check('源码含 v14/v15 特征 %s' % marker, marker in text)

    py_exe = os.path.join(app_root, 'python', 'python.exe')
    imported = False
    if os.path.exists(py_exe):
        code = ('import sys;sys.path.insert(0,"%s");'
                'import src.task.SkipBaseTask as m;print("IMPORT_OK")'
                % working.replace('\\', '/'))
        try:
            r = subprocess.run([py_exe, '-c', code], cwd=working,
                               capture_output=True, timeout=120)
            out = (r.stdout or b'').decode('utf-8', 'replace')
            imported = 'IMPORT_OK' in out
            if imported:
                check('用 ok-ww 自带 python 导入 SkipBaseTask', True)
            else:
                print('  [提示] 导入未成功（ok-script 运行时通常只能在 ok-ww 内部启动），')
                print('         stderr 摘要：%s'
                      % ((r.stderr or b'').decode('utf-8', 'replace').strip().splitlines() or [''])[-1][:160])
        except Exception as exc:
            print('  [提示] 导入检查异常：%s' % exc)
    else:
        print('  [提示] 没找到 ok-ww 自带 python（%s），跳过导入检查' % py_exe)

    if not imported:
        print('  → 退化为**语法编译检查**（不加载第三方依赖）：')
        try:
            tmp = tempfile.mkdtemp(prefix='okww_verify_')
            py_compile.compile(skip_path, cfile=os.path.join(tmp, 'SkipBaseTask.pyc'),
                               doraise=True)
            check('SkipBaseTask.py 语法编译通过', True)
        except Exception as exc:
            check('SkipBaseTask.py 语法编译通过', False, '(%s)' % exc)

    print('')
    print('[5] 运行环境检查')
    for rel in (os.path.join('src', 'task', '__pycache__'), os.path.join('src', '__pycache__')):
        d = os.path.join(working, rel)
        check('%s 已清理' % rel, not os.path.isdir(d),
              '' if not os.path.isdir(d) else '(仍在，可能加载旧字节码)')
    cfg = os.path.join(working, Pkg.REL_CONFIG)
    if os.path.exists(cfg):
        try:
            c = json.load(open(cfg, encoding='utf-8'))
            check('自动对话任务已启用', c.get('_enabled') is True,
                  '(%s)' % json.dumps(c, ensure_ascii=False))
        except Exception as exc:
            print('  [提示] %s 解析失败：%s' % (Pkg.REL_CONFIG, exc))
    else:
        print('  [提示] 没找到 %s，跳过启用状态检查' % Pkg.REL_CONFIG)

    print('')
    print('=' * 66)
    print('自检结果：%d 通过，%d 失败' % (passed, failed))
    if failed == 0:
        print('全部通过 ✓ —— 完全退出 ok-ww（托盘也退）后重新启动即可生效。')
    else:
        print('有失败项，请按上面 [失败] 行排查；回滚方法见 README。')
    print('=' * 66)
    if not args.no_pause:
        try:
            input('按回车键退出...')
        except EOFError:
            pass
    sys.exit(0 if failed == 0 else 1)


if __name__ == '__main__':
    main()
