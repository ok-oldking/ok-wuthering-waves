#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""ok-ww「跳过剧情」修复包 v15 —— 一键安装脚本（纯标准库，不依赖 cv2 / numpy）。

用法：
    python install.py                  # 自动找 ok-ww 目录，合并模式安装
    python install.py --dir D:\\ok-ww  # 手动指定 ok-ww 目录
    python install.py --replace        # 整体覆盖 coco_annotations.json（见 README）

设计要点（都是本项目踩过的坑）：
  1. 幂等：重复运行不产生新备份、不改动内容、不报错。
  2. coco 默认走**合并**：只把 7 张图 + 9 个 category + 9 条 annotation 加进用户
     现有的 coco，其余一字不动。id 一律取 max(existing)+1，不硬编码。
  3. 先备份（`<name>.orig.<时间戳>`）再覆盖；已存在同内容备份时不再新建。
  4. 改完必须删 __pycache__，否则 Python 会加载旧字节码。
  5. 所有写入（代码 / 图片 / coco / 备份）一律**原子写**：同目录临时文件 + os.replace()，
     写到一半被杀也不会留下半截文件（半截 coco 会让 ok-ww 读不了 assets）。
  所有路径均为 ASCII（cv2 写中文路径会静默失败）。
"""
import argparse
import hashlib
import json
import os
import shutil
import sys
import tempfile
import time

# ---- 控制台中文：Windows 下默认 GBK，中文会乱码甚至抛异常 ----
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:      # pragma: no cover - 老版本 Python 没有 reconfigure
    pass

PKG_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION = 15

# 包内文件的期望 md5（装之前先自检包本身是不是完好的）
EXPECTED = {
    'SkipBaseTask.py': ('3536c2f19c33cd36094bbc3fb909d35c', 43209),
    'coco_annotations.json': ('79a37ded743c65221d22ec89389a8ea7', 72791),
    'coco_patch.json': ('34e10f5d646c14b13fe43bb8e092f195', 2947),
    'images/cg2_skip_glyph.png': ('becc5428eff2188c46a72c0cb35ae4d4', 6141),
    'images/cg3_skip_glyph.png': ('dfd83cff4e1861c77c1837e40096005f', 6133),
    'images/cg_hexring.png': ('619ec06aed21caef48f3d35f718df937', 6087),
    'images/cg_skip_text.png': ('2e1842c02b3e66124205d62b0ba99ab8', 6774),
    'images/skip_dialog_glyph.png': ('b3d5173b831688789f8cdb26c816f4ef', 9474),
    'images/skip_dialog_hex.png': ('0862abe010c20943fbe8ec2b9e026ad5', 6739),
    'images/story_ui_r.png': ('70be4cf8e3ab7b0746c50c3f240cd4bd', 8263),
}
# 原版（未打补丁）的 SkipBaseTask.py 指纹，用来提示用户「已经是第几版」
ORIG_SKIP_MD5 = '94330d226d0eb7cee188b1e795c479d0'
# BaseWWTask.py 全程不碰，这里只为校验时展示
BASEWW_EXPECTED_MD5 = '19f41f693928460533181d0115979026'

REL_WORKING = os.path.join('data', 'apps', 'ok-ww', 'working')
REL_SKIP = os.path.join('src', 'task', 'SkipBaseTask.py')
REL_BASE = os.path.join('src', 'task', 'BaseWWTask.py')
REL_COCO = os.path.join('assets', 'coco_annotations.json')
REL_IMAGES = 'assets'
REL_CONFIG = os.path.join('configs', 'AutoDialogTask.json')

WARNINGS = []


def say(msg=''):
    print(msg)


def warn(msg):
    WARNINGS.append(msg)
    print('  [警告] %s' % msg)


def md5_of(path):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def stamp():
    return time.strftime('%Y%m%d_%H%M%S')


def backup_if_needed(path):
    """备份 path 为 `<name>.orig.<时间戳>`。

    幂等关键：若同目录已有**内容相同**的备份，就不再新建（否则每跑一次生成一个
    新文件，用户目录会被垃圾备份塞满）。返回 (备份路径或 None, 是否新建)。
    """
    target_md5 = md5_of(path)
    d = os.path.dirname(path)
    base = os.path.basename(path)
    for fn in os.listdir(d):
        if fn.startswith(base + '.orig.'):
            try:
                if md5_of(os.path.join(d, fn)) == target_md5:
                    return os.path.join(d, fn), False
            except OSError:
                continue
    dst = os.path.join(d, '%s.orig.%s' % (base, stamp()))
    atomic_copy(path, dst)     # 备份也必须原子写：它是唯一的退路，不能写成半截
    return dst, True


def atomic_write_bytes(dst, data):
    """原子写：先写同目录临时文件，再 os.replace() 替换。

    为什么不能直接 open(dst,'wb') 写：写到一半被杀/断电会留下**半截文件**——
    对 coco_annotations.json 这种就是半个 JSON，ok-ww 下次启动直接读不了，
    而这个文件是用户 assets 的核心。os.replace() 在同分区内是原子操作，
    要么看到旧文件、要么看到完整新文件，不存在中间态。
    """
    d = os.path.dirname(os.path.abspath(dst))
    fd, tmp = tempfile.mkstemp(prefix='.okww_fix_', suffix='.tmp', dir=d)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, dst)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def atomic_copy(src, dst):
    with open(src, 'rb') as f:
        atomic_write_bytes(dst, f.read())


def copy_if_changed(src, dst, label):
    """内容一致就什么都不做（幂等），否则先备份再**原子**覆盖。"""
    if os.path.exists(dst) and md5_of(dst) == md5_of(src):
        say('  = %s 已是最新，跳过' % label)
        return False
    if os.path.exists(dst):
        bak, new = backup_if_needed(dst)
        say('  ~ 备份 %s -> %s%s' % (label, os.path.basename(bak),
                                     '' if new else '（已有同内容备份，复用）'))
    else:
        say('  ~ %s 不存在，直接写入' % label)
    atomic_copy(src, dst)
    say('  + 写入 %s（原子替换）' % label)
    return True


def self_check():
    say('[0/5] 检查修复包自身完整性')
    bad = []
    for rel, (want_md5, want_size) in sorted(EXPECTED.items()):
        p = os.path.join(PKG_DIR, rel.replace('/', os.sep))
        if not os.path.exists(p):
            bad.append('%s 缺失' % rel)
            continue
        got_md5, got_size = md5_of(p), os.path.getsize(p)
        if got_md5 != want_md5 or got_size != want_size:
            bad.append('%s 校验失败(md5 %s/%d 字节, 期望 %s/%d)'
                       % (rel, got_md5, got_size, want_md5, want_size))
    if bad:
        for b in bad:
            print('  [错误] %s' % b)
        print('\n修复包文件损坏或不完整，请重新下载解压后再运行。')
        sys.exit(2)
    say('  OK：%d 个文件 md5 全部匹配' % len(EXPECTED))


SKIP_DIRS = {'Windows', 'Program Files', 'Program Files (x86)', 'ProgramData',
             '$Recycle.Bin', 'System Volume Information', 'AppData', 'node_modules',
             '.git', '__pycache__', 'Recovery', 'PerfLogs', 'Intel', 'AMD'}


def looks_like_working(d):
    return os.path.isfile(os.path.join(d, REL_SKIP))


def find_working(root, max_depth=4):
    """在 root 下找 `data/apps/ok-ww/working/src/task/SkipBaseTask.py`，限制深度。"""
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        return None
    for cur, dirs, files in os.walk(root):
        depth = cur[len(root):].count(os.sep)
        if depth >= max_depth:
            dirs[:] = []
            continue
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith('.')]
        if looks_like_working(cur):
            return cur
    return None


def candidate_roots():
    roots = []
    for letter in 'CDEFGHIJKLMNOPQRSTUVWXYZ':
        drv = '%s:\\' % letter
        if os.path.isdir(drv):
            roots.append(drv)
    home = os.path.expanduser('~')
    for sub in ('Desktop', 'Downloads', 'Documents'):
        p = os.path.join(home, sub)
        if os.path.isdir(p):
            roots.append(p)
    if os.path.isdir(home):
        roots.append(home)
    return roots


def locate(args):
    say('[1/5] 定位 ok-ww 安装目录')
    if args.dir:
        d = os.path.abspath(args.dir)
        # 允许传 ok-ww 根目录，也允许直接传 working 目录
        cand = os.path.join(d, REL_WORKING)
        working = cand if looks_like_working(cand) else (d if looks_like_working(d) else None)
        if working:
            say('  找到：%s' % working)
            return os.path.abspath(working)
        print('  [错误] 指定目录下没找到 SkipBaseTask.py：%s' % d)
        print('        请把 --dir 指向 ok-ww 的根目录（里面应有 data\\apps\\ok-ww\\working）')
        sys.exit(3)
    env = os.environ.get('OKWW_DIR')
    if env:
        cand = os.path.join(os.path.abspath(env), REL_WORKING)
        if looks_like_working(cand):
            say('  从环境变量 OKWW_DIR 找到：%s' % cand)
            return os.path.abspath(cand)
    say('  正在常见位置搜索（最多几十秒）...')
    for r in candidate_roots():
        found = find_working(r)
        if found:
            say('  找到：%s' % found)
            return os.path.abspath(found)
    say('  没自动找到。')
    print('\n请手动指定 ok-ww 的根目录，例如：')
    print('    python install.py --dir "D:\\ok-ww"')
    print('（也可以先设置环境变量 OKWW_DIR=<ok-ww 根目录> 再运行）')
    sys.exit(3)


def check_config(working):
    p = os.path.join(working, REL_CONFIG)
    if not os.path.exists(p):
        warn('没找到 %s，无法确认「自动对话」任务是否开启' % REL_CONFIG)
        return
    try:
        cfg = json.load(open(p, encoding='utf-8'))
    except Exception as exc:
        warn('%s 解析失败(%s)，请手动确认「自动对话」任务已启用' % (REL_CONFIG, exc))
        return
    if cfg.get('_enabled') is True:
        say('  OK：自动对话任务已启用(_enabled=true)')
    else:
        warn('自动对话任务未启用(%s) —— 跳过剧情功能不会运行！'
             '请在 ok-ww 里勾选「自动对话」后重启' % json.dumps(cfg, ensure_ascii=False))


def merge_coco(working):
    say('  coco 模式：**合并**（保留你现有的全部内容）')
    coco_path = os.path.join(working, REL_COCO)
    if not os.path.exists(coco_path):
        print('  [错误] 没找到 %s，无法合并' % coco_path)
        sys.exit(4)
    patch = json.load(open(os.path.join(PKG_DIR, 'coco_patch.json'), encoding='utf-8'))
    data = json.load(open(coco_path, encoding='utf-8'))
    before = (len(data['images']), len(data['categories']), len(data['annotations']))

    next_img = max([i['id'] for i in data['images']] or [0]) + 1
    next_cat = max([c['id'] for c in data['categories']] or [0]) + 1
    next_ann = max([a['id'] for a in data['annotations']] or [0]) + 1

    img_id_by_fn = {i['file_name']: i['id'] for i in data['images']}
    cat_id_by_name = {c['name']: c['id'] for c in data['categories']}
    ann_keys = {(a['image_id'], a['category_id']) for a in data['annotations']}

    added_img = added_cat = added_ann = 0
    for item in patch['images']:
        fn = item['file_name']
        if fn in img_id_by_fn:
            say('  = 图片记录已存在，复用 id=%d：%s' % (img_id_by_fn[fn], fn))
            continue
        data['images'].append({'license': 0, 'url': None, 'file_name': fn,
                               'height': item['height'], 'width': item['width'],
                               'date_captured': None, 'id': next_img})
        img_id_by_fn[fn] = next_img
        next_img += 1
        added_img += 1
        say('  + 图片 id=%d：%s (%dx%d)' % (img_id_by_fn[fn], fn, item['width'], item['height']))

    # 记录「已存在的同名类别」里, 哪些是**我们之前装的**(bbox 一致) —— 重复运行时
    # 它们不该再刷一条告警; 只有 bbox 不同(确实是你自己的同名模板)才提示。
    ann_bbox = {(a['image_id'], a['category_id']): a['bbox'] for a in data['annotations']}

    for item in patch['categories']:
        name = item['name']
        if name in cat_id_by_name:
            cid = cat_id_by_name[name]
            # 我这套模板在这张图上应该是什么 bbox
            want = {(it['image'], tuple(it['bbox']))
                    for it in patch['annotations'] if it['category'] == name}
            got = set()
            fn_by_img_id = {v: k for k, v in img_id_by_fn.items()}
            for (iid, c), bbox in ann_bbox.items():
                if c == cid:
                    rev_fn = fn_by_img_id.get(iid)
                    if rev_fn is not None:
                        got.add((rev_fn, tuple(bbox)))
            if want and want <= got:
                say('  = 类别已存在且与本包一致，跳过：%s (id=%d)' % (name, cid))
            else:
                warn('模板「%s」在你的 coco 里已存在(id=%d) 且 bbox 与本包不同，'
                     '保留你的版本、不覆盖' % (name, cid))
            continue
        data['categories'].append({'id': next_cat, 'name': name, 'supercategory': ''})
        cat_id_by_name[name] = next_cat
        next_cat += 1
        added_cat += 1
        say('  + 类别 id=%d：%s' % (cat_id_by_name[name], name))

    for item in patch['annotations']:
        iid = img_id_by_fn.get(item['image'])
        cid = cat_id_by_name.get(item['category'])
        if iid is None or cid is None:
            warn('标注缺少依赖，跳过：%s / %s' % (item['image'], item['category']))
            continue
        if (iid, cid) in ann_keys:
            say('  = 标注已存在，跳过：%s @ %s' % (item['category'], item['image']))
            continue
        bbox = item['bbox']
        data['annotations'].append({'id': next_ann, 'image_id': iid, 'category_id': cid,
                                    'bbox': bbox, 'area': bbox[2] * bbox[3],
                                    'iscrowd': 0, 'ignore': 0, 'segmentation': []})
        ann_keys.add((iid, cid))
        next_ann += 1
        added_ann += 1
        say('  + 标注 id=%d：%s @ %s bbox=%s' % (data['annotations'][-1]['id'],
                                                 item['category'], item['image'], bbox))

    if added_img or added_cat or added_ann:
        bak, new = backup_if_needed(coco_path)
        say('  ~ 备份 coco -> %s%s' % (os.path.basename(bak),
                                       '' if new else '（已有同内容备份，复用）'))
        atomic_write_bytes(coco_path,
                           json.dumps(data, ensure_ascii=False).encode('utf-8'))
        say('  + 写回 coco（原子替换）')
    else:
        say('  = coco 无需改动（9 个模板都已存在）')
    after = (len(data['images']), len(data['categories']), len(data['annotations']))
    say('  coco：images %d->%d  categories %d->%d  annotations %d->%d'
        % (before[0], after[0], before[1], after[1], before[2], after[2]))
    return after


def replace_coco(working):
    say('  coco 模式：**整体覆盖**（会用修复包里的 coco 替换你的，原有自定义模板会丢失）')
    src = os.path.join(PKG_DIR, 'coco_annotations.json')
    dst = os.path.join(working, REL_COCO)
    if os.path.exists(dst):
        bak, new = backup_if_needed(dst)
        say('  ~ 备份 coco -> %s%s' % (os.path.basename(bak),
                                       '' if new else '（已有同内容备份，复用）'))
    else:
        say('  ~ coco 不存在，直接写入')
    atomic_copy(src, dst)
    data = json.load(open(dst, encoding='utf-8'))
    say('  + 写入 coco：images=%d categories=%d annotations=%d'
        % (len(data['images']), len(data['categories']), len(data['annotations'])))
    return (len(data['images']), len(data['categories']), len(data['annotations']))


def clean_pycache(working):
    say('[4/5] 清理 Python 字节码缓存')
    for rel in (os.path.join('src', 'task', '__pycache__'), os.path.join('src', '__pycache__')):
        p = os.path.join(working, rel)
        if os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
            say('  - 已删除 %s' % rel)
    say('  OK（不清的话 ok-ww 会加载旧的 .pyc，补丁看起来“没生效”）')


def verify(working, replace_mode):
    say('[5/5] 安装后校验')
    ok = True
    p = os.path.join(working, REL_SKIP)
    if os.path.exists(p):
        got = md5_of(p)
        want = EXPECTED['SkipBaseTask.py'][0]
        flag = 'OK' if got == want else '不符'
        if got != want:
            ok = False
        say('  %-28s md5 %s (%s)' % (REL_SKIP, got, flag))
    else:
        ok = False
        say('  [错误] %s 不存在' % REL_SKIP)

    p = os.path.join(working, REL_BASE)
    if os.path.exists(p):
        got = md5_of(p)
        untouched = (got == BASEWW_EXPECTED_MD5)
        say('  %-28s md5 %s (%s)' % (REL_BASE, got,
                                     '未被改动 ✓' if untouched else '与本包基准不同（正常，版本差异）'))
    else:
        warn('没找到 BaseWWTask.py（本不该发生，请确认目录正确）')

    miss = []
    for rel in sorted(k for k in EXPECTED if k.startswith('images/')):
        p = os.path.join(working, REL_IMAGES, rel.replace('/', os.sep))
        if not os.path.exists(p):
            miss.append(rel)
        elif md5_of(p) != EXPECTED[rel][0]:
            miss.append(rel + '(md5 不符)')
    say('  模板图片 7 张：%s' % ('全部就位且 md5 匹配' if not miss else '有问题 -> %s' % miss))
    if miss:
        ok = False

    coco_path = os.path.join(working, REL_COCO)
    data = json.load(open(coco_path, encoding='utf-8'))
    names = {c['name'] for c in data['categories']}
    want_names = {c['name'] for c in json.load(
        open(os.path.join(PKG_DIR, 'coco_patch.json'), encoding='utf-8'))['categories']}
    missing = sorted(want_names - names)
    say('  9 个新模板类别：%s' % ('齐全' if not missing else '缺少 %s' % missing))
    if missing:
        ok = False
    say('  coco 计数：images=%d categories=%d annotations=%d'
        % (len(data['images']), len(data['categories']), len(data['annotations'])))
    if replace_mode:
        want = EXPECTED['coco_annotations.json'][0]
        got = md5_of(coco_path)
        say('  覆盖模式 coco md5 %s (%s)' % (got, 'OK' if got == want else '与包内不一致'))
        if got != want:
            ok = False
    return ok


def main():
    ap = argparse.ArgumentParser(description='ok-ww 跳过剧情修复包 v%d 一键安装' % VERSION)
    ap.add_argument('--dir', help='ok-ww 根目录（含 data\\apps\\ok-ww\\working）')
    ap.add_argument('--replace', action='store_true',
                    help='整体覆盖 coco_annotations.json（默认合并）')
    ap.add_argument('--no-pause', action='store_true', help='结尾不暂停（用于自动化）')
    args = ap.parse_args()

    print('=' * 66)
    print('ok-ww「跳过剧情」修复包 v%d —— 一键安装' % VERSION)
    print('=' * 66)
    self_check()
    working = locate(args)
    check_config(working)
    # working = <ok-ww应用目录>/working，其同级就是 python/ 与 configs/ 等
    app_root = os.path.dirname(working)

    say('[2/5] 复制代码与模板图片')
    src_skip = os.path.join(PKG_DIR, 'SkipBaseTask.py')
    dst_skip = os.path.join(working, REL_SKIP)
    if os.path.exists(dst_skip) and md5_of(dst_skip) == ORIG_SKIP_MD5:
        say('  检测到原版 SkipBaseTask.py（未打过补丁）')
    elif os.path.exists(dst_skip) and md5_of(dst_skip) == EXPECTED['SkipBaseTask.py'][0]:
        say('  检测到已安装 v%d，将跳过写入' % VERSION)
    else:
        say('  检测到被修改过的 SkipBaseTask.py（可能装过其它版本），会先备份再覆盖')
    copy_if_changed(src_skip, dst_skip, 'src/task/SkipBaseTask.py')

    img_dst_dir = os.path.join(working, REL_IMAGES, 'images')
    if not os.path.isdir(img_dst_dir):
        os.makedirs(img_dst_dir)
        say('  + 创建目录 assets/images')
    for rel in sorted(k for k in EXPECTED if k.startswith('images/')):
        src = os.path.join(PKG_DIR, rel.replace('/', os.sep))
        dst = os.path.join(img_dst_dir, os.path.basename(rel))
        copy_if_changed(src, dst, rel)

    say('[3/5] 处理 coco_annotations.json')
    if args.replace:
        replace_coco(working)
    else:
        merge_coco(working)

    clean_pycache(working)
    ok = verify(working, args.replace)

    say('')
    say('=' * 66)
    if ok:
        print('安装成功 ✓')
    else:
        print('安装完成，但校验有失败项（见上方 [错误]）—— 请不要急着启 ok-ww')
    print('ok-ww 目录：%s' % app_root)
    print('备份文件：被覆盖的同目录下 `<原名>.orig.<时间戳>`，删掉/改名即可回滚')
    print('')
    print('下一步：**完全退出 ok-ww（托盘图标也退）再重新启动**，它只在启动时加载源码。')
    if WARNINGS:
        print('')
        print('本次有 %d 条警告：' % len(WARNINGS))
        for w in WARNINGS:
            print('  - %s' % w)
    say('=' * 66)
    if not args.no_pause:
        try:
            input('按回车键退出...')
        except EOFError:
            pass
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
