import re
import time

import cv2
import numpy as np
from ok import Logger
from ok.feature.Box import Box

from src.task.BaseWWTask import BaseWWTask, convert_bw, convert_dialog_icon

logger = Logger.get_logger(__name__)

# 同一确认按钮坐标最多重复点击次数。超过即判定点击无效（匹配到了点不动的
# 静态元素或点击未生效），放弃再点，防止单点无效点击构成刷屏死循环
MAX_SAME_POS_CLICKS = 3
# 判断「同一坐标」的容差(像素)
SAME_POS_TOLERANCE = 15
# 一次 try_click_skip 里最多连点几次「跳过」图标。点完确认弹窗弹出后图标不会
# 消失，必须有上限兜底，否则 while 循环退不出去、skip_confirm 永远不执行
MAX_SKIP_CLICKS = 5

# 确认按钮(confirm_btn_*)的**显式**阈值。框架默认 0.8 太低：实机在根本没有弹窗
# 的帧上也能以很高置信度误匹配 confirm_btn_hcenter_vcenter，位置每帧乱跳
# (x 892~1522、y 420~697)，10 分钟里造成 41 次满屏乱点。放到文件顶部，
# 后面按实测样本随时调这一个常量即可，不要散落在调用处。
CONFIRM_BTN_THRESHOLD = 0.9
# 时间稳定性判据（主力修复，不依赖阈值标定）：真正的确认弹窗是**静止**的，
# 连续两次查询的中心点几乎不动；随机误匹配则帧间跳变。所以查两次、中间等
# CONFIRM_STABLE_INTERVAL 秒，中心点漂移 ≤ CONFIRM_STABLE_TOLERANCE 像素才认。
CONFIRM_STABLE_INTERVAL = 0.15
CONFIRM_STABLE_TOLERANCE = 20
# 全局拉黑（兜底保险）：滑动窗口 CONFIRM_COOLDOWN_WINDOW 秒内确认流程尝试
# ≥ CONFIRM_COOLDOWN_MAX_ATTEMPTS 次而弹窗仍未关掉，就判定「这个按钮点不动 /
# 是误匹配」，拉黑 CONFIRM_COOLDOWN_DURATION 秒并打 warning，期间 check_skip
# 直接返回，绝不允许无限刷屏。
CONFIRM_COOLDOWN_WINDOW = 60.0
CONFIRM_COOLDOWN_MAX_ATTEMPTS = 6
CONFIRM_COOLDOWN_DURATION = 60.0
# 【第十一版已删除】OLD_SKIP_TEMPLATE_THRESHOLD(0.85)：它只服务于官方 4K 老模板
# skip_dialog / skip_dialog_new，这两路已在第十一版从 find_skip() 里删除(实机证明
# 它们从未命中真实目标，只制造 conf 0.850/0.859 的误点)，常量随之作废。

# 过场动画型 CG（底部有人名+字幕）的跳过图标字形 cg2_skip_glyph。
# 图形和实机剧情**是同一个**，但位置 (65.5,154)（第十五版更正：旧口径 1616x939 下
# 记作 (73,185)）、尺寸 29x34 —— 与 skip_dialog_glyph
# 的 (87,55)/32x36 不同，模板匹配不吃缩放，旧 glyph 在这批帧上只有 0.4007。
# 搜索区 (0,0.05)-(0.30,0.40) 即绝对像素 x 0~480、y 45~360（标定用的就是这块）；
# 阈值 0.85：跨帧正样本 0.9892~1.0，八张负样本最高 0.328，余量 +0.66。
CG2_GLYPH_BOX = (0.0, 0.05, 0.30, 0.40)
CG2_GLYPH_THRESHOLD = 0.85

# 电影画幅 CG（上下各 112px 纯黑边、内容区 1600x675 的 21:9 宽银幕）的跳过图标
# 字形 cg3_skip_glyph。
# 它和 cg2 那颗是**同一个 ▶| 六边形**，但尺寸是 **31x36** vs cg2 的 **29x34**（差 7%）；
# 模板匹配不吃缩放，实机日志里 cg2 模板在这种帧上只有 conf=0.723（中心 (66,154)），
# 卡在 0.85 之下。
# 巧合可以利用：大图标内缩 6px 后正好也是 19x24、bbox (56,142) —— 与 cg2 的 bbox
# **完全重合**，所以搜索区直接复用 CG2_GLYPH_BOX，不新增比例常量。
# 阈值 0.85：跨帧正样本 0.9881~1.0，与 cg2 帧的交叉分最高 0.7284，余量 +0.26。
CG3_GLYPH_THRESHOLD = 0.85

# 第十三版：尺度无关的 CG 固定坐标兜底（只加常量，不改上面任何一条路径）。
# 由来：第十二版的尺度扫描显示 cg3 模板在 ×1.00 取 1.0000，±3% 就掉到 0.746~0.782，
# 容差带只有约 ±2%；而图标尺寸是**离散的**（29x34 / 31x36 / 实机剧情那颗），
# 再来一种尺寸就得再补一套模板 —— 不能永远这么追。
# 出路：cg2 与 cg3 两个模板的 **bbox 完全相同、都是 (56,142,19,24)**，即两种尺寸的
# 图标**中心恒为 (65.5, 154)**，只是大小不同；而交叉分很整齐：
#   cg3 模板对 cg2 帧 0.7260~0.7284 / cg2 模板对 cg3 帧 0.7171~0.7284
#   负样本最高 0.4857(full_now 半分辨率伪影)、story 0.3632、大世界 0.2921
# → 只要任一 CG 字形模板 ≥ CG_ANY_GLYPH_THRESHOLD，就能确定「那里有一个跳过图标」，
#   而中心必定是 (65.5,154)。位置已知，就不必再依赖模板框 —— 直接点固定坐标，
#   从此不再受尺寸影响（实测可覆盖 28x33 ~ 37x42，约 ±12%，远宽于精确路径的 ±2%）。
CG_ANY_GLYPH_THRESHOLD = 0.60
CG_FIXED_SKIP_CENTER = (65.5, 154.0)
CG_FIXED_SKIP_SIZE = (31, 36)      # 取两种尺寸里较大的那颗，覆盖两者
# 电影画幅判据（固定坐标兜底的佐证，防止盲点）：画面上/下各约 12% 高度的带状区域
# 近乎纯黑（灰度最大值 < 20 且均值 < 15）。实测电影画幅 CG 上下各 112px 纯黑
# （max=0, mean=0.00）；实机剧情/大世界顶部是 UI、底部是场景，均在 80~146, 轻松排除。
CINEMATIC_BAND_RATIO = 0.12
CINEMATIC_MAX_GRAY = 20
CINEMATIC_MEAN_GRAY = 15

# 第十四版：亮背景电影画幅 CG 的**六边形亮环**模板 cg_hexring。
# 场景：同样是电影画幅 CG（上下黑边），但这一幕背景很亮，图标的**视觉极性反转**——
#   * 六边形边框亮白(>200)：icon200 通道里是一个**完整实心六边形**(31x35，白像素
#     占 73.2%)，形状清晰、对比强；
#   * 内部 ▶| 字形是**暗的**：gray 只落在 185~199，与亮背景只差 10~15 灰阶，
#     dark<180 一个像素都没有 —— 所有「白字形」模板全灭（实测 cg2=0.365 /
#     cg3=0.397 / skip_dialog_glyph=0.478 / cg_skip_text=0.33，全在 0.4~0.5）。
# 这是第六版「亮背景冲淡」问题的**中间地带**（那次图标区均值 245 彻底全灭，这次 227
# 还剩一点结构，但字形反色）。字形既然不可用，就改用更稳的六边形轮廓。
# 搜索区 (0,0.10)-(0.1375,0.30) 即 x 0~220、y 90~270 —— 图标只在左上这一小块，
# 收窄搜索区能压低误命中（大世界/剧情帧在这一区的最高分只有 0.3495）。
# 阈值 0.75：正样本 1.0000（⚠️ 自匹配，目前只有这一帧），156 张负样本最高 0.5776
# （是有黑边的暗背景 CG 帧，那里确实有同一颗图标，属于真阳性），无黑边的负样本
# 最高 0.3495；尺度容差实测约 ±6%（±3% 0.82~0.89，±10% 掉到 0.74）。
CG_HEXRING_BOX = (0.0, 0.10, 0.1375, 0.30)
CG_HEXRING_THRESHOLD = 0.75

# 第十版：纯诊断开关（只影响日志，不影响任何判定）。
# check_skip 入口心跳的限流间隔(秒)：trigger 周期是 0.5s，没有心跳时无法区分
# 「AutoDialogTask.run() 的 in_team 早退拦掉了」和「走到了但没认出来」。
CHECK_SKIP_TICK_INTERVAL = 5.0
# 未命中诊断的最小间隔(秒)：只在 find_skip() 走到最后 return None 时才跑，
# 避免 0.5s 周期里每轮都做 4 次模板匹配。
DIAG_INTERVAL = 2.0
# 未命中诊断用的**探索阈值**：故意很低，只为看清「这些模板到底拿了分没有」。
# ⚠️ 这个分数绝对不能当作命中 —— 诊断拿到的 box 一律丢弃，调用点继续 return None。
DIAG_FLOOR_THRESHOLD = 0.40

# 字形模板(skip_dialog_glyph)配套的帧侧处理器: icon 通道 + sigma=1.0 高斯模糊。
# 必须与模板加工链(inRange -> GRAY2BGR -> GaussianBlur(5,5,1.0))完全对称,
# 否则两侧不对称匹配强度会掉。
# 注意下限用 200: BaseWWTask.convert_dialog_icon 用的是 210, 而第五版的基线
# 数据(glyph_blur_out.txt, sigma=1.0)是按 200 测的, 两侧统一用 200 才能复现。
lower_glyph_white = np.array([200, 200, 200], dtype=np.uint8)
upper_glyph_white = np.array([255, 255, 255], dtype=np.uint8)
GLYPH_BLUR_KERNEL = 5
GLYPH_BLUR_SIGMA = 1.0

# 固定坐标兜底：跳过图标被亮背景冲没时（icon 通道抠不出任何结构，第六章详述），
# 改用右上角剧情 UI 按钮判定「我在剧情里」，然后点这个固定坐标。
#
# ⚠️ 第十五版修的 bug：这里原来是 (95, 86)，是**第六版**在 1616x939 BitBlt 抓帧
# 口径下标定的（含 8/31 的窗口边框偏移）。第十一版把所有自建模板统一到 1600x900
# 画布（bbox 统一减了 (8,31)），**漏改了这个常量**，于是兜底点击一直偏 (8,31)。
# 实机铁证（working/logs/ok-script.log，2026-10-10）：11 次 skip_fallback_fixed
# 全部点在 (95,86)，而 skip_dialog_glyph 随后立刻在 (87,55) 命中同一颗图标 ——
# 说明图标一直在 (87,55)，兜底点偏了；y 偏 31 像素而框高只有 36，等于点在框外，
# 所以每次点完确认弹窗都不弹出（wait_until 超时），全靠紧随其后的精确路径补救，
# 用户体感正常、问题被掩盖。一旦图标真被冲没、只剩兜底可用，就会彻底跳不过去。
#
# 结论（旧注释里相反的写法是错的，已删）：这些坐标**必须**与 skip_dialog_glyph
# 模板的 bbox 中心保持一致；`left_click` 日志里打印的就是 Box 中心本身，框架
# **不会**再做任何坐标换算。verify_v15.py 有一条回归断言：从 coco 里读出
# skip_dialog_glyph 的 bbox 算中心与本常量比对，防止以后再动画布时又漏改。
FALLBACK_SKIP_CENTER = (87, 55)
FALLBACK_SKIP_SIZE = (32, 36)      # 与 skip_dialog_glyph 的 bbox 尺寸完全一致
FALLBACK_SKIP_INTERVAL = 2.0       # 秒：同一兜底点击的最小间隔，防止刷屏
# 右上角剧情 UI 按钮的搜索区(覆盖 x 1325~1527、y 63~109)
STORY_UI_BOX = (0.7, 0.0, 1.0, 0.25)
STORY_UI_TEMPLATES = ('story_ui_r1', 'story_ui_r2', 'story_ui_r3')
# CG 剧情「跳过剧情」文字按钮: 暗色阈值 + 搜索区(中下部, 排除顶部 UI)
CG_TEXT_DARK_THRESHOLD = 140
CG_TEXT_BOX = (0.35, 0.45, 1.0, 0.85)


def convert_dialog_icon_noblur(cv_image):
    """icon 通道（与 skip_dialog_glyph / story_ui_r* 同一组 [200,200,200] 下限），
    **不做模糊** —— 配 story_ui_r1/r2/r3 与 skip_dialog_hex 使用。

    为什么不直接用 BaseWWTask.convert_dialog_icon：那个用的是 210 下限，
    在剧情 UI 按钮上只有 0.9325/0.9274/0.9678，而基线（rightbtn_*_out.txt）
    是按 200 测的 0.9905/0.9820/0.9942。模板侧也是按 200 裁的，两侧必须一致。
    """
    match_mask = cv2.inRange(cv_image, lower_glyph_white, upper_glyph_white)
    return cv2.cvtColor(match_mask, cv2.COLOR_GRAY2BGR)


def convert_cg_text(cv_image):
    """CG 剧情「跳过剧情」文字按钮配套的帧侧处理器：**暗色**文字掩码。

    注意通道方向和前面几版相反——CG 那两个按钮是亮底暗字，要抠的是**暗**的部分。
    帧侧与模板侧(cg_skip_text)必须走完全相同的通道，否则不对称。
    """
    gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
    mask = (gray < CG_TEXT_DARK_THRESHOLD).astype(np.uint8) * 255
    return cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)


def convert_dialog_icon_blur(cv_image):
    """icon 通道 + 高斯模糊(σ=1.0)，配 skip_dialog_glyph 模板使用。

    模糊是必需品不是优化：字形 bbox 在 story_frame 与 live_now 之间差 1px，
    而不模糊时 1px 偏移就能让分数从 0.95 掉到 0.65。
    """
    match_mask = cv2.inRange(cv_image, lower_glyph_white, upper_glyph_white)
    output_image = cv2.cvtColor(match_mask, cv2.COLOR_GRAY2BGR)
    return cv2.GaussianBlur(output_image, (GLYPH_BLUR_KERNEL, GLYPH_BLUR_KERNEL), GLYPH_BLUR_SIGMA)


# 第十版：未命中诊断要跑的模板 —— (模板名, 搜索区比例, 帧侧通道函数)。
# 第十三版补上 cg3_skip_glyph（第十版漏了它，导致电影画幅 CG 未命中时诊断表
# 里看不到 cg3 的分数），由四个变五个；第十四版再补 cg_hexring，变六个。
# 三者都**沿用各条正式路径的既有配置**，保证打出来的分数和正式判定同源可比；
# 只有阈值换成 DIAG_FLOOR_THRESHOLD(0.40)，且结果一律不返回。
# 放这里是因为要引用上面的 CG2_GLYPH_BOX / CG_TEXT_BOX / STORY_UI_BOX 和三个处理器。
DIAG_TEMPLATES = (
    ('skip_dialog_glyph', (0.0, 0.0, 0.25, 0.25), convert_dialog_icon_blur),
    ('cg2_skip_glyph', CG2_GLYPH_BOX, convert_dialog_icon_noblur),
    ('cg3_skip_glyph', CG2_GLYPH_BOX, convert_dialog_icon_noblur),
    ('cg_hexring', CG_HEXRING_BOX, convert_dialog_icon_noblur),
    ('cg_skip_text', CG_TEXT_BOX, convert_cg_text),
    ('story_ui_r1', STORY_UI_BOX, convert_dialog_icon_noblur),
)


class SkipBaseTask(BaseWWTask):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.confirm_dialog_checked = False
        self.has_eye_time = 0
        # 确认弹窗点击退避状态：记录上次确认按钮点击位置与重复次数
        self.last_confirm_click_pos = None
        self.same_pos_clicks = 0
        # 固定坐标兜底点击的时间戳（2 秒一次限流）
        self.last_fallback_skip_time = 0.0
        # 确认流程的滑动窗口尝试时间戳列表 + 拉黑截止时间戳（见常量注释）
        self.confirm_attempt_times = []
        self.confirm_cooldown_until = 0.0
        # 第十版诊断日志的时间戳：check_skip 心跳 / find_skip 未命中诊断各一个
        self.last_check_skip_tick_time = 0.0
        self.last_diag_time = 0.0

    def run(self):
        pass

    def skip_confirm(self):
        # 确认弹窗统一走通用 confirm 按钮路径（右半区逐模板查找）。
        # 旧版 skip_quest_confirm/skip_quest_confirm_new 模板已彻底弃用：
        # 它们是旧版弹窗的白色圆角弧线，当前版本弹窗匹配不到；放宽阈值后
        # 实机会在非弹窗界面稳定误匹配(873,555)并每0.7秒盲点一次，构成死循环
        # (2026-10-08 22:53 实机日志)。
        if btn := self.find_skip_confirm_button():
            if self.click_skip_dialog_confirm(btn):
                self.confirm_dialog_checked = True
                self.note_confirm_click(btn)
                return True
        if self.in_team_and_world():
            return True

    def find_skip_confirm_button(self):
        """在屏幕右半区逐模板查找确认按钮（弹窗里取消/确认外观一致，确认在右）。

        不传模板名 list 给 find_one：两个 confirm 模板同时命中同一按钮时
        find_one(list) 会报 too many 且返回哪个模板的结果不确定。普通版优先
        （离线实测 conf 0.998 且命中点更靠按钮中部；highlight 版命中点贴近
        按钮右边缘），不中再查 highlight 版（按钮高亮态时普通版可能失配）。
        """
        for name in ('confirm_btn_hcenter_vcenter', 'confirm_btn_highlight_hcenter_vcenter'):
            if btn := self.find_one(name, box=self.box_of_screen(0.5, 0.4, 1.0, 0.85),
                                    horizontal_variance=0.1, vertical_variance=0.1,
                                    threshold=CONFIRM_BTN_THRESHOLD):
                return btn
        return None

    def confirm_dialog_present(self):
        """确认弹窗是否**真的**在场 —— 时间稳定性判据，返回稳定的按钮 Box 或 None。

        这是第八版的主力修复，不依赖阈值标定。实机现象：confirm_btn_hcenter_vcenter
        在**根本没有弹窗**的帧上也能高置信度误匹配，且命中点每帧乱跳
        (x 892~1522、y 420~697)，10 分钟里造成 41 次满屏乱点；更糟的是
        try_click_skip 因为「找得到确认按钮」而早退，把跳过点击一起压制了
        （cg_skip_text 离线 1.0000，实机却一次都没被点到）。

        判据：真正的弹窗是静止的，随机误匹配是跳变的。所以查两次、中间 sleep
        CONFIRM_STABLE_INTERVAL 秒，两次中心点距离 ≤ CONFIRM_STABLE_TOLERANCE
        像素才认定为真弹窗。

        注意：check_skip() 与 try_click_skip() 里的确认判断**都必须**走这里。
        只改一处的话，另一处的误匹配仍会压制跳过点击。
        """
        first = self.find_skip_confirm_button()
        if not first:
            return None
        self.sleep(CONFIRM_STABLE_INTERVAL)
        second = self.find_skip_confirm_button()
        if not second:
            logger.info(f'confirm_dialog_present: unstable, second lookup found nothing '
                        f'(first was {first.name} at '
                        f'({first.x + first.width / 2:.0f},{first.y + first.height / 2:.0f}))')
            return None
        dx = (second.x + second.width / 2) - (first.x + first.width / 2)
        dy = (second.y + second.height / 2) - (first.y + first.height / 2)
        distance = (dx * dx + dy * dy) ** 0.5
        if distance > CONFIRM_STABLE_TOLERANCE:
            logger.info(f'confirm_dialog_present: rejected, match jumped {distance:.0f}px '
                        f'between two lookups '
                        f'({first.x + first.width / 2:.0f},{first.y + first.height / 2:.0f}) -> '
                        f'({second.x + second.width / 2:.0f},{second.y + second.height / 2:.0f}) '
                        f'— treated as false match, not a dialog')
            return None
        return second

    def confirm_cooldown_active(self):
        """确认流程是否处于全局拉黑期（见 CONFIRM_COOLDOWN_* 常量）。"""
        return time.time() < self.confirm_cooldown_until

    def note_confirm_flow_attempt(self):
        """记一次「确认流程尝试」；窗口内达上限就拉黑并打 warning。

        只统计**真正动手处理**的尝试（不含已退避放弃的轮次）：误匹配的特征是
        位置每帧变化，同坐标退避计数会被冲掉从而持续点击，只有按次数封顶才拦得住。
        """
        now = time.time()
        self.confirm_attempt_times = [t for t in self.confirm_attempt_times
                                      if now - t < CONFIRM_COOLDOWN_WINDOW]
        self.confirm_attempt_times.append(now)
        if len(self.confirm_attempt_times) >= CONFIRM_COOLDOWN_MAX_ATTEMPTS:
            self.confirm_cooldown_until = now + CONFIRM_COOLDOWN_DURATION
            self.confirm_attempt_times = []
            logger.warning(f'confirm flow blacklisted: {CONFIRM_COOLDOWN_MAX_ATTEMPTS} attempts '
                           f'within {CONFIRM_COOLDOWN_WINDOW:.0f}s but dialog never closed. '
                           f'freeze all skip/confirm actions for '
                           f'{CONFIRM_COOLDOWN_DURATION:.0f}s')
            return True
        return False

    def note_confirm_click(self, btn):
        """记录一次确认按钮点击的位置；同一位置(±15px)重复点击则计数累加。"""
        cx, cy = btn.x + btn.width / 2, btn.y + btn.height / 2
        if self.last_confirm_click_pos and \
                abs(cx - self.last_confirm_click_pos[0]) < SAME_POS_TOLERANCE and \
                abs(cy - self.last_confirm_click_pos[1]) < SAME_POS_TOLERANCE:
            self.same_pos_clicks += 1
        else:
            self.same_pos_clicks = 1
        self.last_confirm_click_pos = (cx, cy)

    def confirm_click_exhausted(self, btn):
        """同一确认按钮已点过 MAX_SAME_POS_CLICKS 次而弹窗仍在 -> 点击无效，
        放弃再点（等弹窗消失或按钮位置变化后状态才会复位，见 check_skip）。"""
        if not self.last_confirm_click_pos:
            return False
        cx, cy = btn.x + btn.width / 2, btn.y + btn.height / 2
        return self.same_pos_clicks >= MAX_SAME_POS_CLICKS and \
            abs(cx - self.last_confirm_click_pos[0]) < SAME_POS_TOLERANCE and \
            abs(cy - self.last_confirm_click_pos[1]) < SAME_POS_TOLERANCE

    def log_skip_hit(self, box):
        """find_skip 每次命中都打一条 info（模板名 / box / 置信度）后原样返回。

        为什么必须打：实机只能靠日志复盘「到底是哪条路径点到了哪里」。第七版
        cg_skip_text 离线 1.0000 却实机一次没点到，就是因为没有任何命中日志，
        无从判断是被压制还是没匹配上。
        """
        conf = getattr(box, 'confidence', None)
        conf_str = f'{conf:.3f}' if isinstance(conf, (int, float)) else str(conf)
        logger.info(f'find_skip: hit {box.name} conf={conf_str} '
                    f'box=({box.x},{box.y},{box.width},{box.height}) '
                    f'center=({box.x + box.width / 2:.0f},{box.y + box.height / 2:.0f})')
        return box

    def find_skip(self):
        # 第一优先：skip_dialog_glyph——六边形**内部那个字形**（32x36，来自
        # live_now.png，icon 通道 + σ=1.0 高斯模糊，两侧对称）。
        # 为什么换掉整个六边形：六边形是半透明的，里面透的是游戏场景，场景一动
        # 内容就变，整个六边形做模板天生不稳——跨帧实测只有 0.65（够不到 0.75）；
        # 而且对它加模糊救不了（σ=1.6 时真图标 0.95、右上角干扰也 0.93，余量只剩
        # +0.03）。字形才是 discriminative 的特征：同样位置对右上角三个干扰六边形
        # 只有 0.42，对它加模糊是安全的（σ=1.0 时干扰 0.628）。
        # 模糊是必需品：字形 bbox 在 story_frame 与 live_now 之间差 1px，而不模糊时
        # 1px 偏移就能让分数从 0.95 掉到 0.65。
        # feature_exists 守卫：ok-ww 更新会整目录替换 assets，条目被冲掉时直接
        # find_one 会抛 "not found in featureDict"
        if self.feature_exists('skip_dialog_glyph'):
            if skip_glyph := self.find_one('skip_dialog_glyph',
                                           box=self.box_of_screen(0, 0, 0.25, 0.25),
                                           horizontal_variance=0.02, vertical_variance=0.02,
                                           threshold=0.75,
                                           frame_processor=convert_dialog_icon_blur):
                return self.log_skip_hit(skip_glyph)
        # 第二优先：cg2_skip_glyph——**过场动画型 CG**（底部有人名+字幕）的跳过图标。
        # 这类 CG 是第三种剧情 UI：图标图形和实机剧情相同，但位置 (65.5,154)（第十五版
        # 更正：旧口径 1616x939 下记作 (73,185)）、尺寸
        # 29x34，和 skip_dialog_glyph 的 (87,55)/32x36 对不上——模板匹配不吃缩放，
        # 旧 glyph 在这批帧上只有 0.4007，所以这条路径从来没被触发过（不是第八版
        # 弄坏的，是压根没支持）。
        # 同样**只裁内缩后的中心字形**(56,142,19,24，整六边形 29x34 内缩 5px)：
        # 六边形半透明，里面透的是 CG 画面，整颗做模板会随背景漂移（第四版的教训）。
        # 通道复用 convert_dialog_icon_noblur（icon 200，无模糊）——与第五版 glyph
        # 的区别只有「不加模糊」：这批帧的字形位置四帧完全一致，不需要模糊容错。
        if self.feature_exists('cg2_skip_glyph'):
            if skip_cg2 := self.find_one('cg2_skip_glyph',
                                         box=self.box_of_screen(*CG2_GLYPH_BOX),
                                         horizontal_variance=0.02, vertical_variance=0.02,
                                         threshold=CG2_GLYPH_THRESHOLD,
                                         frame_processor=convert_dialog_icon_noblur):
                return self.log_skip_hit(skip_cg2)
        # 第三优先：cg3_skip_glyph——**电影画幅 CG**（上下各 112px 纯黑边、内容区
        # 1600x675 的 21:9 宽银幕）的跳过图标。图形与 cg2 相同，但尺寸 31x36 vs
        # 29x34（差 7%），模板匹配不吃缩放 → cg2 模板在这种帧上只有 0.723(实机日志)，
        # 卡在 0.85 之下，所以必须再给一条独立路径。
        # 巧合：大图标内缩 6px 后 bbox 正好也是 (56,142,19,24)，与 cg2 完全重合，
        # 只是像素内容每边大 2px → 搜索区直接复用 CG2_GLYPH_BOX，不新增常量。
        # 通道同样是 convert_dialog_icon_noblur（icon 200，无模糊），与 cg2 一致。
        if self.feature_exists('cg3_skip_glyph'):
            if skip_cg3 := self.find_one('cg3_skip_glyph',
                                         box=self.box_of_screen(*CG2_GLYPH_BOX),
                                         horizontal_variance=0.02, vertical_variance=0.02,
                                         threshold=CG3_GLYPH_THRESHOLD,
                                         frame_processor=convert_dialog_icon_noblur):
                return self.log_skip_hit(skip_cg3)
        # 第十四版：下面两条 CG 路径都要用「电影画幅」判据，这里先算一次复用，
        # 免得同一轮里重复做整帧灰度转换（判据本身很便宜，但没理由算三遍）。
        cinematic = self.in_cinematic()
        # 第四优先：cg_hexring——**亮背景**电影画幅 CG（第十四版）。
        # 这一幕背景很亮，图标极性反转：字形是暗的（185~199，与背景只差 10~15 灰阶）
        # → 前面三条白字形路径全灭（cg2 0.365 / cg3 0.397 / glyph 0.478）；但六边形
        # 边框是亮白的，icon200 通道里是一个**完整实心六边形**（31x35，白像素 73.2%），
        # 比 10 灰阶的暗字形稳得多 —— 所以这版的模板抠的是**六边形轮廓**而不是字形。
        # 守卫：必须 in_cinematic() 为真（上下黑边），避免在大世界/剧情里盲点。
        if cinematic:
            if self.feature_exists('cg_hexring'):
                if skip_hexring := self.find_one('cg_hexring',
                                                 box=self.box_of_screen(*CG_HEXRING_BOX),
                                                 horizontal_variance=0.02,
                                                 vertical_variance=0.02,
                                                 threshold=CG_HEXRING_THRESHOLD,
                                                 frame_processor=convert_dialog_icon_noblur):
                    return self.log_skip_hit(skip_hexring)
        # 第十三版：**尺度无关**的 CG 固定坐标兜底（放在两条 0.85 精确路径之后）。
        # 精确匹配优先（模板框更准）；只有两套模板都够不到 0.85、但任一 ≥ 0.60 时
        # 才走这里 —— 说明「那里确实有个跳过图标，只是尺寸不是我们见过的那两种」。
        # 因为 cg2 / cg3 的 bbox 完全相同、中心恒为 (65.5,154)，所以**不返回模板框**，
        # 直接返回固定坐标 Box，从此不再受尺寸影响。
        # 双重保险：① ≥0.60 的字形门槛（负样本最高只有 0.4857）
        #          ② in_cinematic() 电影画幅判据（上下黑边），防止在别的界面盲点。
        # 第十四版：把 cg_hexring 也加进查询集合 —— 它让这条兜底同时覆盖**两种极性**
        # （白字形 / 六边形亮环）。亮背景 CG 上 cg2/cg3 只有 0.365/0.397，原本兜底
        # 根本不触发；而 hexring 即便图标缩到 90% 也还有 0.7493，够 0.60 → 照旧点
        # 固定坐标。安全性：有黑边的负样本里 hexring 最高 0.5776（暗背景 CG 帧，那里
        # 本来就有同一颗图标，属真阳性），无黑边的负样本最高 0.3495。
        if cinematic:
            for name, qbox in (('cg2_skip_glyph', CG2_GLYPH_BOX),
                               ('cg3_skip_glyph', CG2_GLYPH_BOX),
                               ('cg_hexring', CG_HEXRING_BOX)):
                if not self.feature_exists(name):
                    continue
                if self.find_one(name, box=self.box_of_screen(*qbox),
                                 horizontal_variance=0.02, vertical_variance=0.02,
                                 threshold=CG_ANY_GLYPH_THRESHOLD,
                                 frame_processor=convert_dialog_icon_noblur):
                    cx, cy = CG_FIXED_SKIP_CENTER
                    w, h = CG_FIXED_SKIP_SIZE
                    logger.warning(f'cg skip fallback: {name} >= {CG_ANY_GLYPH_THRESHOLD} '
                                   f'but below its precise threshold -> icon size/polarity '
                                   f'unknown, click fixed position ({cx},{cy})')
                    return self.log_skip_hit(
                        Box(cx - w / 2, cy - h / 2, w, h, 1.0, 'cg_skip_fixed'))
        # 第五优先：cg_skip_text——CG/演出剧情是**另一套 UI**：屏幕中间偏下(y≈620)
        # 有两个并排按钮，右 = 跳过剧情(中心 x≈1020)，左 = 继续播放(中心 x≈592)。
        # 这个界面里左上角六边形图标和右上角剧情 UI 按钮都不存在，第五/六版路径
        # 都不会触发，所以 CG 需要独立路径。
        # 关键陷阱：**不能把整颗按钮做成模板**——两颗按钮外圈边框完全相同、文字
        # 占比太小，右按钮模板在左按钮「继续播放」上能拿 0.8165~0.8497(>0.75)
        # 会误点。所以只裁 inset=10 剥掉边框后的中间文字 (982,610,77,20)，
        # 实测右=1.0000、左(干扰)=0.3590，余量 +0.6410。
        # 通道是**暗色**文字掩码(gray<140)，与上面几版的亮色 inRange 相反。
        if self.feature_exists('cg_skip_text'):
            if skip_cg := self.find_one('cg_skip_text', box=self.box_of_screen(*CG_TEXT_BOX),
                                        horizontal_variance=0.02, vertical_variance=0.02,
                                        threshold=0.75,
                                        frame_processor=convert_cg_text):
                return self.log_skip_hit(skip_cg)
        # 第六优先：skip_dialog_hex——左上角「跳过」六边形图标**完整**轮廓(46x45，
        # 含边框，assets/images/skip_dialog_hex.png + coco_annotations.json 新条目)。
        # 为什么需要它：实机剧情(木轩对话)的图标中心约 (96,88)，而旧模板 skip_dialog
        # 的规范位置是 (87,55)，y 偏差 30px=0.032，超出 vertical_variance=0.02
        # (±19px) 的搜索窗，扫不到；且 skip_dialog 只是 23x24 的字形部分，缩放后
        # 糊了，实测局部匹配仅 0.54。新模板实测对剧情帧 1.000、对加载界面 0.321。
        # 为什么必须限定区域：右上角的「自动播放」也是六边形，不受限时会拿到
        # 0.795(>0.75) 被误点，所以搜索限定在画面左上 1/4。
        # feature_exists 先判一次：ok-ww 更新会整目录替换 assets，若模板条目被
        # 冲掉而本文件还在，直接 find_one 会抛 "not found in featureDict"
        if self.feature_exists('skip_dialog_hex'):
            if skip_hex := self.find_one('skip_dialog_hex', box=self.box_of_screen(0, 0, 0.25, 0.25),
                                         horizontal_variance=0.02, vertical_variance=0.02,
                                         threshold=0.75,
                                         frame_processor=convert_dialog_icon):
                return self.log_skip_hit(skip_hex)
        # 【第十一版已删除】这里原本还有两路官方 4K 老模板 skip_dialog / skip_dialog_new。
        # 删除理由(实机证据)：这两个模板从未命中过真实目标，只在 1600x900 实机帧上
        # 制造误命中 —— conf 0.850 / 0.859，点出去的位置是 (65,154)/(65,155)，
        # 正好卡在第八版抬到 0.85 的阈值线上方。官方模板是按 4K 分辨率建的，在
        # 1600x900 帧上被缩放后只剩噪声级相似；而真正该点的目标已由
        # skip_dialog_glyph / cg2_skip_glyph / cg_skip_text / skip_dialog_hex 四条
        # 自建路径(第十一版已统一到 1600x900 画布)覆盖，这两路纯属误点源。
        # 连带删除的还有常量 OLD_SKIP_TEMPLATE_THRESHOLD(不再有使用者)。
        # 最后兜底：跳过按钮的六边形是半透明的，背后场景很亮时按钮和背景融成一片，
        # icon 通道抠不出任何结构（实测图标区灰度均值 245.6、标准差仅 18.7，正常帧是
        # 221/27.9；CLAHE、自适应对比度、inRange 放宽到 150 等六种预处理全部 miss，
        # 最高 0.53）——这是特征不存在，不是阈值问题，模板层面无解。
        # 此时改判「我是否在剧情里」：右上角三个剧情 UI 按钮（自动播放/隐藏界面）
        # 在剧情帧上 0.98+，在大世界只有 0.12~0.19，分离度 0.8 以上。确认在剧情
        # 就点固定坐标 (87,55)（= FALLBACK_SKIP_CENTER，与 skip_dialog_glyph 的
        # 命中框中心完全一致；第十五版之前这里写的是旧口径的 (95,86)），
        # 并做 2 秒一次限流防止刷屏。
        if self.in_story_ui():
            now = time.time()
            if now - self.last_fallback_skip_time >= FALLBACK_SKIP_INTERVAL:
                self.last_fallback_skip_time = now
                cx, cy = FALLBACK_SKIP_CENTER
                w, h = FALLBACK_SKIP_SIZE
                logger.warning(f'fallback skip click at fixed position ({cx},{cy}), '
                               f'skip icon washed out by bright background')
                return self.log_skip_hit(Box(cx - w / 2, cy - h / 2, w, h, 1.0, 'skip_fallback_fixed'))
            logger.debug('fallback skip click throttled, wait for interval')
        # 全部路径都没命中。第十版：先打一条纯诊断日志（2 秒一次，只为取分），
        # 然后**照旧 return None** —— 诊断结果绝不参与判定，也不产生任何点击。
        self.log_skip_diag()
        return None

    def in_cinematic(self):
        """画面是否为「电影画幅 CG」（上下黑边的宽银幕）—— 固定坐标兜底的**佐证**判据。

        判据：顶部与底部各约 CINEMATIC_BAND_RATIO(12%) 高度的带状区域近乎纯黑
        （灰度最大值 < 20 且均值 < 15）。实测电影画幅 CG 上下各 112px 是**真纯黑**
        （max=0 / mean=0.00）；实机剧情、大世界顶部有 UI、底部是场景，均值 58~146，
        轻松排除。

        ⚠️ 必须知道的例外（实测确认）：**双按钮 CG（cg_0/cg_1/cg_2/confirm_now）
        同样有上下黑边**，这个判据对它们也是 True。它们不会被误点到 (65.5,154)，
        靠的是另一道保险 —— 那类帧上 cg2 / cg3 字形模板连 0.05 的探索阈值都过不了
        （返回 None），所以 ≥0.60 的兜底根本不会触发。
        """
        frame = getattr(self, 'frame', None)
        if frame is None:
            return False
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        height = gray.shape[0]
        band = max(1, int(round(height * CINEMATIC_BAND_RATIO)))
        top, bottom = gray[:band], gray[height - band:]
        top_max, top_mean = int(top.max()), float(top.mean())
        bottom_max, bottom_mean = int(bottom.max()), float(bottom.mean())
        result = (top_max < CINEMATIC_MAX_GRAY and top_mean < CINEMATIC_MEAN_GRAY and
                  bottom_max < CINEMATIC_MAX_GRAY and bottom_mean < CINEMATIC_MEAN_GRAY)
        logger.debug(f'in_cinematic: top(max={top_max} mean={top_mean:.2f}) '
                     f'bottom(max={bottom_max} mean={bottom_mean:.2f}) -> {result}')
        return result

    def log_skip_diag(self):
        """未命中时的**纯诊断**：用很低的探索阈值把各条路径的最高分打出来。

        为什么要它：第九版只记录「命中」不记录「未命中」。实机 03:18:48 重启后日志里
        一条 SkipBaseTask 都没有，无法区分
          A. AutoDialogTask.run() 开头的 in_team 早退 -> check_skip 压根没被调用
          B. 进了剧情但模板都没过阈（新 UI 变体 / 背景太亮）
        有了这些分数就能判断是「没走到」还是「走到了没认出来」。配套还有 check_skip
        入口的心跳日志（见 CHECK_SKIP_TICK_INTERVAL）。

        ⚠️ 这里拿到的 box **一律丢弃**，调用点必须继续 return None：探索阈值只有
        DIAG_FLOOR_THRESHOLD=0.40，拿到的多半是噪声，返回它就变成误点乱点了。
        """
        now = time.time()
        if now - self.last_diag_time < DIAG_INTERVAL:
            return
        self.last_diag_time = now
        for name, box_ratio, processor in DIAG_TEMPLATES:
            if not self.feature_exists(name):
                logger.info(f'find_skip diag: {name} not installed, skipped')
                continue
            found = self.find_one(name, box=self.box_of_screen(*box_ratio),
                                  horizontal_variance=0.02, vertical_variance=0.02,
                                  threshold=DIAG_FLOOR_THRESHOLD, frame_processor=processor)
            if found:
                conf = getattr(found, 'confidence', None)
                conf_str = f'{conf:.3f}' if isinstance(conf, (int, float)) else str(conf)
                logger.info(f'find_skip diag: {name} conf={conf_str} '
                            f'center=({found.x + found.width / 2:.0f},'
                            f'{found.y + found.height / 2:.0f}) '
                            f'(explore threshold {DIAG_FLOOR_THRESHOLD}, NOT a hit)')
            else:
                logger.info(f'find_skip diag: {name} none below {DIAG_FLOOR_THRESHOLD}')

    def in_story_ui(self):
        """右上角的三个剧情 UI 按钮（自动播放/隐藏界面/…）是否可见 —— 用来判断
        「当前确实在剧情里」。

        这三个按钮在剧情帧上 0.98+，在大世界只有 0.12~0.19（实测剧情 vs 大世界
        差 0.8 以上），阈值 0.75 放在中间，分离度极好。跳过按钮本身被亮背景冲没时，
        它们是唯一还能用的剧情信号。逐模板单独查询，不传 list。
        """
        box = self.box_of_screen(*STORY_UI_BOX)
        for name in STORY_UI_TEMPLATES:
            if not self.feature_exists(name):
                continue
            if self.find_one(name, box=box, horizontal_variance=0.02, vertical_variance=0.02,
                             threshold=0.75, frame_processor=convert_dialog_icon_noblur):
                return True
        return False

    def try_click_skip(self):
        # 点完「跳过」后确认弹窗会弹出，但**左上角跳过图标并不会消失**，
        # 原 while 循环因此退不出去，会以 0.2s 间隔反复点已被弹窗遮住的位置，
        # skip_confirm() 永远得不到执行——这是实机「卡死不动」的真身。
        # 两道保险：① 每次再点前先查确认弹窗是否已出现，出现就 break；
        # ② 连点上限 MAX_SKIP_CLICKS，超出后 return True 把弹窗交给 skip_confirm。
        skipped = False
        clicks = 0
        while skip := self.find_skip():
            if clicks >= MAX_SKIP_CLICKS:
                logger.warning(f'try_click_skip: clicked skip {clicks}x but icon still there, '
                               f'last box {skip}, hand over to skip_confirm')
                return True
            # 确认弹窗已弹出就不再点跳过图标（点了也没用，图标被弹窗盖住）。
            # 必须用 confirm_dialog_present() 而不是 find_skip_confirm_button()：
            # 后者在实机的非弹窗帧上会稳定误匹配（位置每帧乱跳），一误判就把
            # 跳过点击全压制掉 —— 这正是第七版 cg_skip_text 离线 1.0000、
            # 实机一次都点不到的原因。
            if self.confirm_dialog_present():
                logger.info('try_click_skip: confirm dialog already open, stop clicking skip icon')
                return True
            logger.info('Click Skip Dialog')
            self.click_box(skip, after_sleep=0.2)
            clicks += 1
            skipped = True
        return skipped

    def check_skip(self):
        # 心跳（第十版）：只要日志里出现 'skip tick: entering check_skip'，就说明
        # AutoDialogTask.run() 开头的 in_team 早退**没有**拦掉本次调用 —— 用来区分
        # 「check_skip 压根没被调用」和「调用了但模板没过阈」。5 秒一次限流，
        # 免得 0.5s 的 trigger 周期把日志刷爆。
        tick_now = time.time()
        if tick_now - self.last_check_skip_tick_time >= CHECK_SKIP_TICK_INTERVAL:
            self.last_check_skip_tick_time = tick_now
            logger.info('skip tick: entering check_skip')
        # 全局拉黑期：前面 60 秒内确认流程尝试 ≥6 次弹窗仍未关掉，说明按钮点不动
        # 或匹配是假的。此时一律不动手，60 秒后再说（宁可暂停，也不刷屏死循环）。
        if self.confirm_cooldown_active():
            logger.warning(f'check_skip: confirm flow still blacklisted for '
                           f'{self.confirm_cooldown_until - time.time():.0f}s, do nothing')
            return True
        if self.try_click_skip():
            # 弹窗淡入约0.3秒，期间模板匹配会失败，等待窗口放宽到5秒让
            # wait_until 轮询到弹窗稳定
            self.note_confirm_flow_attempt()
            return self.wait_until(self.skip_confirm, time_out=5, raise_if_not_found=False)
        # 兜底：确认弹窗可能已在之前某轮打开但没被处理掉（孤儿弹窗——此时界面
        # 已没有跳过图标，try_click_skip 永远返回 False），主动识别并关掉它。
        # 同样只认「时间稳定」的匹配，避免把随机误匹配当成弹窗去点。
        if btn := self.confirm_dialog_present():
            if self.confirm_click_exhausted(btn):
                # 同一坐标已点 MAX_SAME_POS_CLICKS 次弹窗仍在，重复点击无意义，
                # 本轮放弃，绝不刷屏死循环
                logger.warning(f'confirm button at {self.last_confirm_click_pos} clicked '
                               f'{self.same_pos_clicks}x but dialog persists, back off')
                return True
            self.note_confirm_flow_attempt()
            logger.info('skip confirm dialog still open, handle it')
            return self.wait_until(self.skip_confirm, time_out=5, raise_if_not_found=False)
        # 弹窗已关闭：复位点击退避状态
        self.last_confirm_click_pos = None
        self.same_pos_clicks = 0


dialog_white_color = {
    'r': (230, 255),  # Red range
    'g': (230, 255),  # Green range
    'b': (230, 255)  # Blue range
}

dialog_black_color = {
    'r': (0, 15),  # Red range
    'g': (0, 15),  # Green range
    'b': (0, 15)  # Blue range
}
